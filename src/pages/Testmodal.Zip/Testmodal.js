import React from "react";
import { useEffect, useState } from "react";
import selfscore1_img1 from "../images/selfscore1_img1.png";
import test2_selfscore1_img1 from "../images/test2_selfscore1_img1.png";
import test2_selfscore2_img1 from "../images/test2_selfscore2_img1.png";
import test2_selfscore2_img2 from "../images/test2_selfscore2_img2.png";
import test2_selfscore2_img3 from "../images/test2_selfscore2_img3.png";
import test2_selfscore2_img4 from "../images/test2_selfscore2_img4.png";
import test2_selfscore3_img1 from "../images/test2_selfscore3_img1.png";
import test2_selfscore3_img2 from "../images/test2_selfscore3_img2.png";
import React3D from "./React3D";
import "./Modal.css";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
const selftest1_result = 5;

const Testmodal = () => {
  const [modalShow, setModalShow] = useState(false);
  const Selftest2_score1 = () => {
    return (
      <div>
        <div>검사 일시: 년 월 일</div>
        <h1>ADHD의 증상이 발견되지 않았습니다</h1>
        <br />
        <h4>아래의 항목을 보고 실천해 보세요.</h4>
        <br />
        <div style={{ display: "flex" }}>
          <img src={selfscore1_img1} style={{ width: "200px" }} />
          <div>
            <p>
              규칙적인 수면과 식습관을 지켜 생체리듬의 균형을 잘 잡아야 합니다.
            </p>
            <p>수면시 주변의 소음을 최소화합니다.</p>
            <p>자기전 카페인이 들어간 음식을 자재하십시오</p>
            <p>아침,점심,저녁은 대략 5시간 간격으로 먹도록 합시다.</p>
          </div>
        </div>
        <br />
        <div style={{ display: "flex" }}>
          <img src={test2_selfscore1_img1} style={{ width: "200px" }} />
          <div>
            <p>집중력 향상에 대한 방안으로 아래의 방법을 추천드립니다.</p>
            <p>스도쿠</p>
            <p>하루 계획 세우기</p>
            <p>집중이 잘 되는 장소 선택하기</p>
            <p>최소30분, 최대1시간 간격으로 뇌를 잠깐 쉬어주기</p>
          </div>
        </div>
        <br />
        <h3>다른 회원과 결과를 비교해보세요.</h3>
        <React3D />
      </div>
    );
  };
  const Selftest2_score2 = () => {
    return (
      <div>
        <div>검사 일시: 년 월 일</div>
        <h1>ADHD가 의심됩니다.</h1>
        <br />
        <h4>아래의 항목을 보고 자신이 어떤 종류의 ADHD인지 확인해보세요.</h4>
        <br />
        <div style={{ display: "flex" }}>
          <img src={test2_selfscore2_img1} style={{ width: "200px" }} />
          <div>
            <h3>과잉행동-충동형 ADHD-PH</h3>
            <p>
              차분하게 앉아있지 못하고 부산하거나 계속 움직이는 것을 말합니다.
            </p>
            <p>
              자주 넘어지고 다치거나 높은 곳에 기어오르며 어릴 때 '가만히 있지
              못한다'는 말을 많이 듣습니다.{" "}
            </p>
            <p>
              청소년의 경우 또래에 비해 과격한 행동을 하고 눈치 없는 행동을 많이
              하는 유형이므로 선생님들에게 지적을 자주 받습니다.
            </p>
          </div>
        </div>
        <br />
        <div style={{ display: "flex" }}>
          <img src={test2_selfscore2_img2} style={{ width: "200px" }} />
          <div>
            <h3>주의력 결핍형 ADHD-PI</h3>
            <p>과잉행동은 없지만 주의력이 많이 낮은 유형입니다.</p>
            <p>
              재미있는 놀이나 게임은 오랫동안 집중할 수 있지만, 재미없고
              반복적이거나 힘든 활동은 시작하기도 어렵고, 다른 행동을 하느라
              중단되기 일쑤입니다.
            </p>
            <p>
              해야할 것을 잘 까먹고, 물건을 자주 잃어버리기도 하며, 멍하니
              있거나 딴생각을 하느라 다른사람의 말을 놓치는 경우가 많습니다.
            </p>
          </div>
        </div>
        <br />
        <div style={{ display: "flex" }}>
          <img
            src={test2_selfscore2_img3}
            style={{ width: "200px", height: "200px" }}
          />
          <div>
            <h3>혼합형 ADHD-C</h3>
            <p>
              주의력 결핍형과 과잉행동-충동형의 특징을 모두 가지고 있는
              증상입니다.
            </p>
            <p>전체의 약 55%를 차지합니다.</p>
          </div>
        </div>
        <br />
        <div style={{ display: "flex" }}>
          <img
            src={test2_selfscore2_img4}
            style={{ width: "200px", height: "200px" }}
          />
          <div>
            <p>아래의 방법으로 전두엽 향상 훈련을 해보세요.</p>
            <p>획일적인 결정 자제하기</p>
            <p>
              아동의 경우: 부모님이 아동에게 스스로 할 수 있는 적정량의 임무를
              주기
            </p>
            <p>
              성인의 경우:지나치게 무리한 일정을 줄이고 스마트폰 이용시간도
              줄이기
            </p>
            <p>
              그 외에 전두엽을 자극할 수 있는 대표적인 방법으로
              뜨개질,종이접기,악기 배우기가 있습니다.
            </p>
          </div>
        </div>
        <br />
        <h3>다른 회원과 결과를 비교해보세요.</h3>
        <React3D />
      </div>
    );
  };

  const Selftest2_score3 = () => {
    return (
      <div>
        <div>검사 일시: 년 월 일</div>
        <h1>
          ADHD가 의심되는 아주 높은 수치입니다. 전문가와의 상담을 요합니다.
        </h1>
        <br />
        <h4>아래의 항목에 치료방안이 제시되어있습니다.</h4>
        <br />
        <div style={{ display: "flex" }}>
          <img src={test2_selfscore3_img1} style={{ width: "200px" }} />
          <div>
            <h4>약물치료</h4>
            <p>메틸페니데이트계열: 콘서타,메디키넷,메타데이트 CR</p>
            <p>NRI 계열:아토목세틴,클로니딘</p>
            <p>
              정신과 약을 복용시 본인의 상태나,약효,부작용등은 항상 기록하여
              상담할 때 이용해주시기바랍니다.
            </p>
          </div>
        </div>
        <br />
        <div style={{ display: "flex" }}>
          <img src={test2_selfscore3_img2} style={{ width: "200px" }} />
          <div>
            <h4>CAT(종합주의력) 검사</h4>
            <p>단순선택주의력 검사</p>
            <p>억제지속주의력 검사</p>
            <p>간섭선택주의력 검사</p>
            <p>분할주의력 검사</p>
            <p>작업기억력 검사</p>
          </div>
        </div>
        <br />
        <h3>다른 회원과 결과를 비교해보세요.</h3>
        <React3D />
      </div>
    );
  };

  function MyVerticallyCenteredModal(props) {
    return (
      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">검사결과</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selftest1_result < 30 ? <Selftest2_score1 /> : null}
          {selftest1_result >= 30 && selftest1_result <= 40 ? (
            <Selftest2_score2 />
          ) : null}
          {selftest1_result >= 41 ? <Selftest2_score3 /> : null}
        </Modal.Body>
        <Modal.Footer>
          <Button onClick={props.onHide}>Close</Button>
        </Modal.Footer>
      </Modal>
    );
  }
  return (
    <div>
      <div className="btn-area">
        <input
          type="button"
          value="제출하기"
          className="selftest1_btn"
          onClick={() => setModalShow(true)}
          style={{
            width: "150px",
            height: "70px",
            marginBottom: "20px",
          }}
        />
      </div>
      <div>
        <MyVerticallyCenteredModal
          show={modalShow}
          onHide={() => setModalShow(false)}
        />
      </div>
    </div>
  );
};

export default Testmodal;
